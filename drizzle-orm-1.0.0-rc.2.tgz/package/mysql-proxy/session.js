import { entityKind, is } from "../entity.js";
import { Column } from "../column.js";
import { makeJitQueryMapper, mapResultRow } from "../utils.js";
import { fillPlaceholders } from "../sql/sql.js";
import { NoopLogger } from "../logger.js";
import { NoopCache } from "../cache/core/index.js";
import { MySqlPreparedQuery, MySqlSession } from "../mysql-core/session.js";
import { makeJitRqbMapper } from "../relations.js";
import { MySqlTransaction as MySqlTransaction$1 } from "../mysql-core/index.js";

//#region src/mysql-proxy/session.ts
var MySqlRemoteSession = class extends MySqlSession {
	static [entityKind] = "MySqlRemoteSession";
	logger;
	cache;
	constructor(client, dialect, relations, schema, options) {
		super(dialect);
		this.client = client;
		this.relations = relations;
		this.schema = schema;
		this.options = options;
		this.logger = options.logger ?? new NoopLogger();
		this.cache = options.cache ?? new NoopCache();
	}
	prepareQuery(query, fields, customResultMapper, generatedIds, returningIds, queryMetadata, cacheConfig) {
		return new PreparedQuery(this.client, query.sql, query.params, this.logger, this.cache, queryMetadata, cacheConfig, fields, this.options.useJitMappers, customResultMapper, generatedIds, returningIds);
	}
	prepareRelationalQuery(query, fields, customResultMapper, config, generatedIds, returningIds) {
		return new PreparedQuery(this.client, query.sql, query.params, this.logger, this.cache, void 0, void 0, fields, this.options.useJitMappers, customResultMapper, generatedIds, returningIds, true, config);
	}
	all(query) {
		const querySql = this.dialect.sqlToQuery(query);
		this.logger.logQuery(querySql.sql, querySql.params);
		return this.client(querySql.sql, querySql.params, "all").then(({ rows }) => rows);
	}
	async transaction(_transaction, _config) {
		throw new Error("Transactions are not supported by the MySql Proxy driver");
	}
};
var MySqlProxyTransaction = class extends MySqlTransaction$1 {
	static [entityKind] = "MySqlProxyTransaction";
	async transaction(_transaction) {
		throw new Error("Transactions are not supported by the MySql Proxy driver");
	}
};
var PreparedQuery = class extends MySqlPreparedQuery {
	static [entityKind] = "MySqlProxyPreparedQuery";
	jitMapper;
	constructor(client, queryString, params, logger, cache, queryMetadata, cacheConfig, fields, useJitMappers, customResultMapper, generatedIds, returningIds, isRqbV2Query, rqbConfig) {
		super(cache, queryMetadata, cacheConfig);
		this.client = client;
		this.queryString = queryString;
		this.params = params;
		this.logger = logger;
		this.fields = fields;
		this.useJitMappers = useJitMappers;
		this.customResultMapper = customResultMapper;
		this.generatedIds = generatedIds;
		this.returningIds = returningIds;
		this.isRqbV2Query = isRqbV2Query;
		this.rqbConfig = rqbConfig;
	}
	async execute(placeholderValues = {}) {
		if (this.isRqbV2Query) return this.executeRqbV2(placeholderValues);
		const params = fillPlaceholders(this.params, placeholderValues);
		const { fields, client, queryString, logger, joinsNotNullableMap, customResultMapper, returningIds, generatedIds } = this;
		logger.logQuery(queryString, params);
		if (!fields && !customResultMapper) {
			const { rows: data } = await this.queryWithCache(queryString, params, async () => {
				return await client(queryString, params, "execute");
			});
			const insertId = data[0].insertId;
			const affectedRows = data[0].affectedRows;
			if (returningIds) {
				const returningResponse = [];
				let j = 0;
				for (let i = insertId; i < insertId + affectedRows; i++) {
					for (const column of returningIds) {
						const key = returningIds[0].path[0];
						if (is(column.field, Column)) {
							if (column.field.primary && column.field.autoIncrement) returningResponse.push({ [key]: i });
							if (column.field.defaultFn && generatedIds) returningResponse.push({ [key]: generatedIds[j][key] });
						}
					}
					j++;
				}
				return returningResponse;
			}
			return data;
		}
		const { rows } = await this.queryWithCache(queryString, params, async () => {
			return await client(queryString, params, "all");
		});
		if (customResultMapper) return customResultMapper(rows);
		return this.useJitMappers ? (this.jitMapper = this.jitMapper ?? makeJitQueryMapper(fields, joinsNotNullableMap))(rows) : rows.map((row) => mapResultRow(fields, row, joinsNotNullableMap));
	}
	async executeRqbV2(placeholderValues = {}) {
		const params = fillPlaceholders(this.params, placeholderValues);
		const { client, queryString, logger, customResultMapper } = this;
		logger.logQuery(queryString, params);
		const { rows: res } = await client(queryString, params, "execute");
		const rows = res[0];
		return this.useJitMappers ? (this.jitMapper = this.jitMapper ?? makeJitRqbMapper(this.rqbConfig))(rows) : customResultMapper(rows);
	}
	iterator(_placeholderValues = {}) {
		throw new Error("Streaming is not supported by the MySql Proxy driver");
	}
};

//#endregion
export { MySqlProxyTransaction, MySqlRemoteSession, PreparedQuery };
//# sourceMappingURL=session.js.map