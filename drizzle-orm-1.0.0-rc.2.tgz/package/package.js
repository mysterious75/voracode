//#region package.json
var version = "1.0.0-rc.2";

//#endregion
export { version };
//# sourceMappingURL=package.js.map