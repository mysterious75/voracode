import { ViewBaseConfig } from "../view-common.js";
import { DrizzleError } from "../errors.js";
import { and, eq } from "../sql/expressions/conditions.js";
import { MsSqlViewBase } from "./view-base.js";
import { MsSqlColumn } from "./columns/common.js";
import { MsSqlTable } from "./table.js";
import { entityKind, is } from "../entity.js";
import { Subquery } from "../subquery.js";
import { Table, getTableName, getTableUniqueName } from "../table.js";
import { Column } from "../column.js";
import { orderSelectedFields } from "../utils.js";
import { Param, SQL, View, sql } from "../sql/sql.js";
import { getMigrationsToRun } from "../migrator.utils.js";
import * as V1 from "../_relations.js";
import { aliasedTable, aliasedTableColumn, getOriginalColumnFromAlias, mapColumnsInAliasedSQLToAlias, mapColumnsInSQLToAlias } from "../alias.js";
import { upgradeIfNeeded } from "../up-migrations/mssql.js";

//#region src/mssql-core/dialect.ts
var MsSqlDialect = class {
	static [entityKind] = "MsSqlDialect";
	constructor(_config) {}
	async migrate(migrations, session, config) {
		const migrationsSchema = typeof config === "string" ? "drizzle" : config.migrationsSchema ?? "drizzle";
		const migrationSchemaCreate = sql`
			IF NOT EXISTS (
				SELECT 1 FROM sys.schemas WHERE name = ${migrationsSchema}
			)
			EXEC(\'CREATE SCHEMA ${sql.identifier(migrationsSchema)}\')
		`;
		await session.execute(migrationSchemaCreate);
		const migrationsTable = typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const { newDb } = await upgradeIfNeeded(migrationsSchema, migrationsTable, session, migrations);
		if (newDb) {
			const migrationTableCreate = sql`
			IF NOT EXISTS (
				SELECT 1 FROM INFORMATION_SCHEMA.TABLES 
				WHERE TABLE_NAME = ${migrationsTable} AND TABLE_SCHEMA = ${migrationsSchema}
			)
			CREATE TABLE ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} (
				id bigint identity PRIMARY KEY,
				hash text NOT NULL,
				created_at bigint,
				name text,
				applied_at datetime2 NOT NULL DEFAULT GETUTCDATE()
			)
		`;
			await session.execute(migrationTableCreate);
		}
		const dbMigrations = (await session.execute(sql`select id, hash, created_at, name from ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)}`)).recordset;
		if (typeof config === "object" && config.init) {
			if (dbMigrations.length > 0) return { exitCode: "databaseMigrations" };
			if (migrations.length > 1) return { exitCode: "localMigrations" };
			const [migration] = migrations;
			if (!migration) return;
			await session.execute(sql`insert into ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} ([hash], [created_at], [name]) values(${migration.hash}, ${migration.folderMillis}, ${migration.name})`);
			return;
		}
		const migrationsToRun = getMigrationsToRun({
			localMigrations: migrations,
			dbMigrations
		});
		await session.transaction(async (tx) => {
			for (const migration of migrationsToRun) {
				for (const stmt of migration.sql) await tx.execute(sql.raw(stmt));
				await tx.execute(sql`insert into ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} ([hash], [created_at], [name]) values(${migration.hash}, ${migration.folderMillis}, ${migration.name})`);
			}
		});
	}
	escapeName(name) {
		return `[${name.replace(/\]/g, "]]")}]`;
	}
	escapeParam(_num) {
		return `@par${_num}`;
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildDeleteQuery({ table, where, output }) {
		return sql`delete from ${table}${output ? sql` output ${this.buildSelectionOutput(output, { type: "DELETED" })}` : void 0}${where ? sql` where ${where}` : void 0}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setSize = columnNames.length;
		return sql.join(columnNames.flatMap((colName, i) => {
			const col = tableColumns[colName];
			const onUpdateFnResult = col.onUpdateFn?.();
			const value = set[colName] ?? (is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col));
			const res = sql`${sql.identifier(col.name)} = ${value}`;
			if (i < setSize - 1) return [res, sql.raw(", ")];
			return [res];
		}));
	}
	buildUpdateQuery({ table, set, where, output }) {
		const setSql = this.buildUpdateSet(table, set);
		const outputSql = sql``;
		if (output) {
			outputSql.append(sql` output `);
			if (output.inserted) outputSql.append(this.buildSelectionOutput(output.inserted, { type: "INSERTED" }));
			if (output.deleted) {
				if (output.inserted) outputSql.append(sql`, `);
				outputSql.append(this.buildSelectionOutput(output.deleted, { type: "DELETED" }));
			}
		}
		return sql`update ${table} set ${setSql}${outputSql}${where ? sql` where ${where}` : void 0}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false } = {}) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if (is(field, SQL.Aliased) && field.isSelectionField) {
				if (!isSingleTable && field.origin !== void 0) chunk.push(sql.identifier(field.origin), sql.raw("."));
				chunk.push(sql.identifier(field.fieldAlias));
			} else if (is(field, SQL.Aliased) || is(field, SQL)) {
				const query = is(field, SQL.Aliased) ? field.sql : field;
				if (isSingleTable) {
					const newSql = new SQL(query.queryChunks.map((c) => {
						if (is(c, MsSqlColumn)) return sql.identifier(c.name);
						return c;
					}));
					chunk.push(query.shouldInlineParams ? newSql.inlineParams() : newSql);
				} else chunk.push(query);
				if (is(field, SQL.Aliased)) chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
			} else if (is(field, Column)) if (isSingleTable) chunk.push(field.isAlias ? sql`${sql.identifier(getOriginalColumnFromAlias(field).name)} as ${field}` : sql.identifier(field.name));
			else chunk.push(field.isAlias ? sql`${getOriginalColumnFromAlias(field)} as ${field}` : field);
			else if (is(field, Subquery)) {
				const entries = Object.entries(field._.selectedFields);
				if (entries.length === 1) {
					const entry = entries[0][1];
					const fieldDecoder = is(entry, SQL) ? entry.decoder : is(entry, Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
					if (fieldDecoder) field._.sql.decoder = fieldDecoder;
				}
				chunk.push(field);
			}
			if (i < columnsLen - 1) chunk.push(sql`, `);
			return chunk;
		});
		return sql.join(chunks);
	}
	buildSelectionOutput(fields, { type }) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if (is(field, SQL.Aliased) && field.isSelectionField) chunk.push(sql.join([sql.raw(`${type}.`), sql.identifier(field.fieldAlias)]));
			else if (is(field, SQL.Aliased) || is(field, SQL)) {
				const query = is(field, SQL.Aliased) ? field.sql : field;
				chunk.push(new SQL(query.queryChunks.map((c) => {
					if (is(c, MsSqlColumn)) return sql.join([sql.raw(`${type}.`), sql.identifier(c.name)]);
					return c;
				})));
				if (is(field, SQL.Aliased)) chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
			} else if (is(field, Column)) chunk.push(sql.join([sql.raw(`${type}.`), field.isAlias ? sql`${sql.identifier(getOriginalColumnFromAlias(field).name)} as ${field}` : sql.identifier(field.name)]));
			if (i < columnsLen - 1) chunk.push(sql`, `);
			return chunk;
		});
		return sql.join(chunks);
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, fetch, for: _for, top, offset, distinct, setOperators }) {
		const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
		for (const f of fieldsList) if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, MsSqlViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : getTableName(table)) && !((table) => joins?.some(({ alias }) => alias === (table[Table.Symbol.IsAlias] ? getTableName(table) : table[Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = getTableName(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		let withSql;
		if (withList?.length) {
			const withSqlChunks = [sql`with `];
			for (const [i, w] of withList.entries()) {
				withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
				if (i < withList.length - 1) withSqlChunks.push(sql`, `);
			}
			withSqlChunks.push(sql` `);
			withSql = sql.join(withSqlChunks);
		}
		const distinctSql = distinct ? sql` distinct` : void 0;
		const topSql = top ? sql` top(${top})` : void 0;
		const selection = this.buildSelection(fieldsList, { isSingleTable });
		const tableSql = (() => {
			if (is(table, Table) && table[Table.Symbol.OriginalName] !== table[Table.Symbol.Name]) {
				let fullName = sql`${sql.identifier(table[Table.Symbol.OriginalName])} ${sql.identifier(table[Table.Symbol.Name])}`;
				if (table[Table.Symbol.Schema]) fullName = sql`${sql.identifier(table[Table.Symbol.Schema])}.${fullName}`;
				return fullName;
			}
			if (is(table, View) && table[ViewBaseConfig].isAlias) {
				let fullName = sql`${sql.identifier(table[ViewBaseConfig].originalName)}`;
				if (table[ViewBaseConfig].schema) fullName = sql`${sql.identifier(table[ViewBaseConfig].schema)}.${fullName}`;
				return sql`${fullName} ${sql.identifier(table[ViewBaseConfig].name)}`;
			}
			return table;
		})();
		const joinsArray = [];
		if (joins) for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(sql` `);
			const table = joinMeta.table;
			const lateralSql = joinMeta.lateral ? sql` lateral` : void 0;
			if (is(table, MsSqlTable)) {
				const tableName = table[MsSqlTable.Symbol.Name];
				const tableSchema = table[MsSqlTable.Symbol.Schema];
				const origTableName = table[MsSqlTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`} on ${joinMeta.on}`);
			} else if (is(table, View)) {
				const viewName = table[ViewBaseConfig].name;
				const viewSchema = table[ViewBaseConfig].schema;
				const origViewName = table[ViewBaseConfig].originalName;
				const alias = viewName === origViewName ? void 0 : joinMeta.alias;
				joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? sql`${sql.identifier(viewSchema)}.` : void 0}${sql.identifier(origViewName)}${alias && sql` ${sql.identifier(alias)}`} on ${joinMeta.on}`);
			} else joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${table} on ${joinMeta.on}`);
			if (index < joins.length - 1) joinsArray.push(sql` `);
		}
		const joinsSql = sql.join(joinsArray);
		const whereSql = where ? sql` where ${where}` : void 0;
		const havingSql = having ? sql` having ${having}` : void 0;
		let orderBySql;
		if (orderBy && orderBy.length > 0) orderBySql = sql` order by ${sql.join(orderBy, sql`, `)}`;
		let groupBySql;
		if (groupBy && groupBy.length > 0) groupBySql = sql` group by ${sql.join(groupBy, sql`, `)}`;
		const offsetSql = offset === void 0 ? void 0 : sql` offset ${offset} rows`;
		const fetchSql = fetch === void 0 ? void 0 : sql` fetch next ${fetch} rows only`;
		let forSQL;
		if (_for && _for.mode === "json") forSQL = sql` for json ${sql.raw(_for.type)}${_for.options?.root ? sql` root(${sql.identifier(_for.options.root)})` : void 0}${_for.options?.includeNullValues ? sql` include_null_values` : void 0}${_for.options?.withoutArrayWrapper ? sql` without_array_wrapper` : void 0}`;
		const finalQuery = sql`${withSql}select${distinctSql}${topSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${offsetSql}${fetchSql}${forSQL}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		const [setOperator, ...rest] = setOperators;
		if (!setOperator) throw new Error("Cannot pass undefined values to any set operator");
		if (rest.length === 0) return this.buildSetOperationQuery({
			leftSelect,
			setOperator
		});
		return this.buildSetOperations(this.buildSetOperationQuery({
			leftSelect,
			setOperator
		}), rest);
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, fetch, orderBy, offset } }) {
		const leftChunk = sql`(${leftSelect.getSQL()}) `;
		const rightChunk = sql`(${rightSelect.getSQL()})`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const orderByUnit of orderBy) if (is(orderByUnit, MsSqlColumn)) orderByValues.push(sql.identifier(orderByUnit.name));
			else if (is(orderByUnit, SQL)) {
				for (let i = 0; i < orderByUnit.queryChunks.length; i++) {
					const chunk = orderByUnit.queryChunks[i];
					if (is(chunk, MsSqlColumn)) orderByUnit.queryChunks[i] = sql.identifier(chunk.name);
				}
				orderByValues.push(sql`${orderByUnit}`);
			} else orderByValues.push(sql`${orderByUnit}`);
			orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)} `;
		}
		const offsetSql = offset === void 0 ? void 0 : sql` offset ${offset} rows`;
		const fetchSql = fetch === void 0 ? void 0 : sql` fetch next ${fetch} rows only`;
		return sql`${leftChunk}${sql.raw(`${type} ${isAll ? "all " : ""}`)}${rightChunk}${orderBySql}${offsetSql}${fetchSql}`;
	}
	buildInsertQuery({ table, values, output }) {
		const valuesSqlList = [];
		const columns = table[Table.Symbol.Columns];
		const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrder = colEntries.map(([, column]) => sql.identifier(column.name));
		for (const [valueIndex, value] of values.entries()) {
			const valueList = [];
			for (const [fieldName, col] of colEntries) {
				const colValue = value[fieldName];
				if (colValue === void 0 || is(colValue, Param) && colValue.value === void 0) if (col.defaultFn !== void 0) {
					const defaultFnResult = col.defaultFn();
					const defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
					valueList.push(defaultValue);
				} else if (!col.default && col.onUpdateFn !== void 0) {
					const onUpdateFnResult = col.onUpdateFn();
					const newValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
					valueList.push(newValue);
				} else valueList.push(sql`default`);
				else valueList.push(colValue);
			}
			valuesSqlList.push(valueList);
			if (valueIndex < values.length - 1) valuesSqlList.push(sql`, `);
		}
		const valuesSql = insertOrder.length === 0 ? void 0 : sql.join(valuesSqlList);
		const outputSql = output ? sql` output ${this.buildSelectionOutput(output, { type: "INSERTED" })}` : void 0;
		return sql`insert into ${table} ${insertOrder.length === 0 ? sql`default` : insertOrder}${outputSql} values ${valuesSql}`;
	}
	sqlToQuery(sql, invokeSource) {
		return sql.toQuery({
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			invokeSource
		});
	}
	buildRelationalQuery({ fullSchema, schema, tableNamesMap, table, tableConfig, queryConfig: config, tableAlias, nestedQueryRelation, joinOn }) {
		let selection = [];
		let limit, offset, orderBy = [], where;
		if (config === true) selection = Object.entries(tableConfig.columns).map(([key, value]) => ({
			dbKey: value.name,
			tsKey: key,
			field: aliasedTableColumn(value, tableAlias),
			relationTableTsKey: void 0,
			isJson: false,
			selection: []
		}));
		else {
			const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)]));
			if (config.where) {
				const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, V1.getOperators()) : config.where;
				where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
			}
			const fieldsSelection = [];
			let selectedColumns = [];
			if (config.columns) {
				let isIncludeMode = false;
				for (const [field, value] of Object.entries(config.columns)) {
					if (value === void 0) continue;
					if (field in tableConfig.columns) {
						if (!isIncludeMode && value === true) isIncludeMode = true;
						selectedColumns.push(field);
					}
				}
				if (selectedColumns.length > 0) selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
			} else selectedColumns = Object.keys(tableConfig.columns);
			for (const field of selectedColumns) {
				const column = tableConfig.columns[field];
				fieldsSelection.push({
					tsKey: field,
					value: column
				});
			}
			let selectedRelations = [];
			if (config.with) selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({
				tsKey,
				queryConfig,
				relation: tableConfig.relations[tsKey]
			}));
			let extras;
			if (config.extras) {
				extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
				for (const [tsKey, value] of Object.entries(extras)) fieldsSelection.push({
					tsKey,
					value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
				});
			}
			for (const { tsKey, value } of fieldsSelection) selection.push({
				dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
				tsKey,
				field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
				relationTableTsKey: void 0,
				isJson: false,
				selection: []
			});
			let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, V1.getOrderByOperators()) : config.orderBy ?? [];
			if (!Array.isArray(orderByOrig)) orderByOrig = [orderByOrig];
			orderBy = orderByOrig.map((orderByValue) => {
				if (is(orderByValue, Column)) return aliasedTableColumn(orderByValue, tableAlias);
				return mapColumnsInSQLToAlias(orderByValue, tableAlias);
			});
			limit = config.limit;
			offset = config.offset;
			for (const { tsKey: selectedRelationTsKey, queryConfig: selectedRelationConfigValue, relation } of selectedRelations) {
				const normalizedRelation = V1.normalizeRelation(schema, tableNamesMap, relation);
				const relationTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
				const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
				const joinOn = and(...normalizedRelation.fields.map((field, i) => eq(aliasedTableColumn(normalizedRelation.references[i], relationTableAlias), aliasedTableColumn(field, tableAlias))));
				const builtRelation = this.buildRelationalQuery({
					fullSchema,
					schema,
					tableNamesMap,
					table: fullSchema[relationTableTsName],
					tableConfig: schema[relationTableTsName],
					queryConfig: is(relation, V1.One) ? selectedRelationConfigValue === true ? { limit: 1 } : {
						...selectedRelationConfigValue,
						limit: 1
					} : selectedRelationConfigValue,
					tableAlias: relationTableAlias,
					joinOn,
					nestedQueryRelation: relation
				});
				let fieldSql = sql`(${builtRelation.sql} for json auto, include_null_values)${nestedQueryRelation ? sql` as ${sql.identifier(relationTableAlias)}` : void 0}`;
				if (is(relation, V1.Many)) fieldSql = sql`${fieldSql}`;
				const field = fieldSql.as(selectedRelationTsKey);
				selection.push({
					dbKey: selectedRelationTsKey,
					tsKey: selectedRelationTsKey,
					field,
					relationTableTsKey: relationTableTsName,
					isJson: true,
					selection: builtRelation.selection
				});
			}
		}
		if (selection.length === 0) throw new DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.` });
		let result;
		where = and(joinOn, where);
		if (nestedQueryRelation) {
			let field = sql`${sql.join(selection.map((sel) => {
				return is(sel.field, MsSqlColumn) ? sql.identifier(sel.field.name) : is(sel.field, SQL.Aliased) ? sel.isJson ? sel.field.sql : sql`${sel.field.sql} as ${sql.identifier(sel.field.fieldAlias)}` : sel.field;
			}), sql`, `)}`;
			if (is(nestedQueryRelation, V1.Many)) field = sql`${field}`;
			const nestedSelection = [{
				dbKey: "data",
				tsKey: "data",
				field,
				isJson: true,
				relationTableTsKey: tableConfig.tsName,
				selection
			}];
			result = aliasedTable(table, tableAlias);
			const top = offset ? void 0 : limit ?? void 0;
			const fetch = offset && limit ? limit : void 0;
			if (orderBy.length === 0 && offset !== void 0 && fetch !== void 0) orderBy = [sql`1`];
			result = this.buildSelectQuery({
				table: is(result, MsSqlTable) ? result : new Subquery(result, {}, tableAlias),
				fields: {},
				fieldsFlat: nestedSelection.map(({ field }) => ({
					path: [],
					field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
				})),
				where,
				top,
				offset,
				fetch,
				orderBy,
				setOperators: []
			});
		} else {
			const top = offset ? void 0 : limit ?? void 0;
			const fetch = offset && limit ? limit : void 0;
			if (orderBy.length === 0 && offset !== void 0 && fetch !== void 0) orderBy = [sql`1`];
			result = this.buildSelectQuery({
				table: aliasedTable(table, tableAlias),
				fields: {},
				fieldsFlat: selection.map(({ field }) => ({
					path: [],
					field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
				})),
				where,
				top,
				offset,
				fetch,
				orderBy,
				setOperators: []
			});
		}
		return {
			tableTsKey: tableConfig.tsName,
			sql: result,
			selection
		};
	}
};

//#endregion
export { MsSqlDialect };
//# sourceMappingURL=dialect.js.map