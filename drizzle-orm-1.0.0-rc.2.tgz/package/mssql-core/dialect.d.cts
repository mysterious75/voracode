import { MsSqlColumn } from "./columns/common.cjs";
import { MsSqlDeleteConfig } from "./query-builders/delete.cjs";
import { MsSqlInsertConfig } from "./query-builders/insert.cjs";
import { MsSqlUpdateConfig } from "./query-builders/update.cjs";
import { MsSqlTable } from "./table.cjs";
import { MsSqlSession } from "./session.cjs";
import { MsSqlSelectConfig } from "./query-builders/select.types.cjs";
import { entityKind } from "../entity.cjs";
import { Query, SQL } from "../sql/sql.cjs";
import { UpdateSet } from "../utils.cjs";
import * as V1 from "../_relations.cjs";
import { MigrationConfig, MigrationMeta, MigratorInitFailResponse } from "../migrator.cjs";

//#region src/mssql-core/dialect.d.ts
interface MsSqlDialectConfig {}
declare class MsSqlDialect {
  static readonly [entityKind]: string;
  constructor(_config?: MsSqlDialectConfig);
  migrate(migrations: MigrationMeta[], session: MsSqlSession, config: MigrationConfig): Promise<void | MigratorInitFailResponse>;
  escapeName(name: string): string;
  escapeParam(_num: number): string;
  escapeString(str: string): string;
  buildDeleteQuery({
    table,
    where,
    output
  }: MsSqlDeleteConfig): SQL;
  buildUpdateSet(table: MsSqlTable, set: UpdateSet): SQL;
  buildUpdateQuery({
    table,
    set,
    where,
    output
  }: MsSqlUpdateConfig): SQL;
  /**
   * Builds selection SQL with provided fields/expressions
   *
   * Examples:
   *
   * `select <selection> from`
   *
   * `insert ... returning <selection>`
   *
   * If `isSingleTable` is true, then columns won't be prefixed with table name
   */
  private buildSelection;
  private buildSelectionOutput;
  buildSelectQuery({
    withList,
    fields,
    fieldsFlat,
    where,
    having,
    table,
    joins,
    orderBy,
    groupBy,
    fetch,
    for: _for,
    top,
    offset,
    distinct,
    setOperators
  }: MsSqlSelectConfig): SQL;
  buildSetOperations(leftSelect: SQL, setOperators: MsSqlSelectConfig['setOperators']): SQL;
  buildSetOperationQuery({
    leftSelect,
    setOperator: {
      type,
      isAll,
      rightSelect,
      fetch,
      orderBy,
      offset
    }
  }: {
    leftSelect: SQL;
    setOperator: MsSqlSelectConfig['setOperators'][number];
  }): SQL;
  buildInsertQuery({
    table,
    values,
    output
  }: MsSqlInsertConfig): SQL;
  sqlToQuery(sql: SQL, invokeSource?: 'indexes' | 'mssql-check' | 'mssql-view-with-schemabinding'): Query;
  buildRelationalQuery({
    fullSchema,
    schema,
    tableNamesMap,
    table,
    tableConfig,
    queryConfig: config,
    tableAlias,
    nestedQueryRelation,
    joinOn
  }: {
    fullSchema: Record<string, unknown>;
    schema: V1.TablesRelationalConfig;
    tableNamesMap: Record<string, string>;
    table: MsSqlTable;
    tableConfig: V1.TableRelationalConfig;
    queryConfig: true | V1.DBQueryConfig<'many', true>;
    tableAlias: string;
    nestedQueryRelation?: V1.Relation;
    joinOn?: SQL;
  }): V1.BuildRelationalQueryResult<MsSqlTable, MsSqlColumn>;
}
//#endregion
export { MsSqlDialect, MsSqlDialectConfig };
//# sourceMappingURL=dialect.d.cts.map