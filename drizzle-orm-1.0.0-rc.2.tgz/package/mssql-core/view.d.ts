import { MsSqlViewBase } from "./view-base.js";
import { QueryBuilder } from "./query-builders/query-builder.js";
import { MsSqlViewConfig } from "./view-common.js";
import { SelectedFields } from "./query-builders/select.types.js";
import { entityKind } from "../entity.js";
import { Casing } from "../casing.js";
import { ColumnsSelection, SQL } from "../sql/sql.js";
import { BuildColumns, ColumnBuilderBase } from "../column-builder.js";
import { TypedQueryBuilder } from "../query-builders/query-builder.js";
import { AddAliasToSelection } from "../query-builders/select.types.js";

//#region src/mssql-core/view.d.ts
interface ViewBuilderConfig {
  encryption?: boolean;
  schemaBinding?: boolean;
  viewMetadata?: boolean;
  checkOption?: boolean;
}
declare class ViewBuilderCore<TConfig extends {
  name: string;
  columns?: unknown;
}> {
  protected name: TConfig['name'];
  protected schema: string | undefined;
  static readonly [entityKind]: string;
  readonly _: {
    readonly name: TConfig['name'];
    readonly columns: TConfig['columns'];
  };
  constructor(name: TConfig['name'], schema: string | undefined);
  protected config: ViewBuilderConfig;
  with(config?: ViewBuilderConfig): this;
}
declare class ViewBuilder<TName extends string = string> extends ViewBuilderCore<{
  name: TName;
}> {
  static readonly [entityKind]: string;
  as<TSelectedFields extends SelectedFields>(qb: TypedQueryBuilder<TSelectedFields> | ((qb: QueryBuilder) => TypedQueryBuilder<TSelectedFields>)): MsSqlViewWithSelection<TName, false, AddAliasToSelection<TSelectedFields, TName, 'mssql'>>;
}
declare class ManualViewBuilder<TName extends string = string, TColumns extends Record<string, ColumnBuilderBase> = Record<string, ColumnBuilderBase>> extends ViewBuilderCore<{
  name: TName;
  columns: TColumns;
}> {
  static readonly [entityKind]: string;
  private columns;
  constructor(name: TName, columns: TColumns, schema: string | undefined, casing: Casing | undefined);
  existing(): MsSqlViewWithSelection<TName, true, BuildColumns<TName, TColumns, 'mssql'>>;
  as(query: SQL): MsSqlViewWithSelection<TName, false, BuildColumns<TName, TColumns, 'mssql'>>;
}
declare class MsSqlView<TName extends string = string, TExisting extends boolean = boolean, TSelectedFields extends ColumnsSelection = ColumnsSelection> extends MsSqlViewBase<TName, TExisting, TSelectedFields> {
  static readonly [entityKind]: string;
  protected $MsSqlViewBrand: 'MsSqlView';
  [MsSqlViewConfig]: ViewBuilderConfig | undefined;
  constructor({
    mssqlConfig,
    config
  }: {
    mssqlConfig: ViewBuilderConfig | undefined;
    config: {
      name: TName;
      schema: string | undefined;
      selectedFields: SelectedFields;
      query: SQL | undefined;
    };
  });
}
type MsSqlViewWithSelection<TName extends string, TExisting extends boolean, TSelectedFields extends ColumnsSelection> = MsSqlView<TName, TExisting, TSelectedFields> & TSelectedFields;
interface MsSqlViewFn {
  <TName extends string>(name: TName): ViewBuilder<TName>;
  <TName extends string, TColumns extends Record<string, ColumnBuilderBase>>(name: TName, columns: TColumns): ManualViewBuilder<TName, TColumns>;
}
declare const mssqlView: MsSqlViewFn;
//#endregion
export { ManualViewBuilder, MsSqlView, MsSqlViewFn, MsSqlViewWithSelection, ViewBuilder, ViewBuilderConfig, ViewBuilderCore, mssqlView };
//# sourceMappingURL=view.d.ts.map