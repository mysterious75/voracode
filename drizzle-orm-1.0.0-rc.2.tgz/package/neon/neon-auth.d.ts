import * as __pg_core_index_ts0 from "../pg-core/index.js";

//#region src/neon/neon-auth.d.ts
/**
 * Table schema of the `users_sync` table used by Neon Auth.
 * This table automatically synchronizes and stores user data from external authentication providers.
 *
 * @schema neon_auth
 * @table users_sync
 */
declare const usersSync: __pg_core_index_ts0.PgTableWithColumns<{
  name: "users_sync";
  schema: "neon_auth";
  columns: {
    rawJson: __pg_core_index_ts0.PgBuildColumn<"users_sync", __pg_core_index_ts0.SetNotNull<__pg_core_index_ts0.PgJsonbBuilder>, {
      name: string;
      tableName: "users_sync";
      dataType: "object json";
      data: unknown;
      driverParam: unknown;
      notNull: true;
      hasDefault: false;
      isPrimaryKey: false;
      isAutoincrement: false;
      hasRuntimeDefault: false;
      enumValues: undefined;
      identity: undefined;
      generated: undefined;
    }>;
    id: __pg_core_index_ts0.PgBuildColumn<"users_sync", __pg_core_index_ts0.SetNotNull<__pg_core_index_ts0.SetIsPrimaryKey<__pg_core_index_ts0.PgTextBuilder<[string, ...string[]]>>>, {
      name: string;
      tableName: "users_sync";
      dataType: "string";
      data: string;
      driverParam: string;
      notNull: true;
      hasDefault: false;
      isPrimaryKey: false;
      isAutoincrement: false;
      hasRuntimeDefault: false;
      enumValues: undefined;
      identity: undefined;
      generated: undefined;
    }>;
    name: __pg_core_index_ts0.PgBuildColumn<"users_sync", __pg_core_index_ts0.PgTextBuilder<[string, ...string[]]>, {
      name: string;
      tableName: "users_sync";
      dataType: "string";
      data: string;
      driverParam: string;
      notNull: false;
      hasDefault: false;
      isPrimaryKey: false;
      isAutoincrement: false;
      hasRuntimeDefault: false;
      enumValues: undefined;
      identity: undefined;
      generated: undefined;
    }>;
    email: __pg_core_index_ts0.PgBuildColumn<"users_sync", __pg_core_index_ts0.PgTextBuilder<[string, ...string[]]>, {
      name: string;
      tableName: "users_sync";
      dataType: "string";
      data: string;
      driverParam: string;
      notNull: false;
      hasDefault: false;
      isPrimaryKey: false;
      isAutoincrement: false;
      hasRuntimeDefault: false;
      enumValues: undefined;
      identity: undefined;
      generated: undefined;
    }>;
    createdAt: __pg_core_index_ts0.PgBuildColumn<"users_sync", __pg_core_index_ts0.PgTimestampStringBuilder, {
      name: string;
      tableName: "users_sync";
      dataType: "string timestamp";
      data: string;
      driverParam: string;
      notNull: false;
      hasDefault: false;
      isPrimaryKey: false;
      isAutoincrement: false;
      hasRuntimeDefault: false;
      enumValues: undefined;
      identity: undefined;
      generated: undefined;
    }>;
    deletedAt: __pg_core_index_ts0.PgBuildColumn<"users_sync", __pg_core_index_ts0.PgTimestampStringBuilder, {
      name: string;
      tableName: "users_sync";
      dataType: "string timestamp";
      data: string;
      driverParam: string;
      notNull: false;
      hasDefault: false;
      isPrimaryKey: false;
      isAutoincrement: false;
      hasRuntimeDefault: false;
      enumValues: undefined;
      identity: undefined;
      generated: undefined;
    }>;
    updatedAt: __pg_core_index_ts0.PgBuildColumn<"users_sync", __pg_core_index_ts0.PgTimestampStringBuilder, {
      name: string;
      tableName: "users_sync";
      dataType: "string timestamp";
      data: string;
      driverParam: string;
      notNull: false;
      hasDefault: false;
      isPrimaryKey: false;
      isAutoincrement: false;
      hasRuntimeDefault: false;
      enumValues: undefined;
      identity: undefined;
      generated: undefined;
    }>;
  };
  dialect: "pg";
}>;
//#endregion
export { usersSync };
//# sourceMappingURL=neon-auth.d.ts.map