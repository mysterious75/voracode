import { entityKind } from "../entity.js";
import { Assume } from "../utils.js";
import { Query } from "../sql/sql.js";
import { Logger } from "../logger.js";
import { PgDialect } from "../pg-core/dialect.js";
import { Cache } from "../cache/core/index.js";
import { PgAsyncPreparedQuery, PgAsyncSession, PgAsyncTransaction } from "../pg-core/async/session.js";
import { AnyRelations } from "../relations.js";
import { Row, RowList, Sql, TransactionSql } from "postgres";
import { WithCacheConfig } from "../cache/core/types.js";
import { PgQueryResultHKT, PgTransactionConfig, PreparedQueryConfig } from "../pg-core/session.js";

//#region src/postgres-js/session.d.ts
interface PostgresJsSessionOptions {
  logger?: Logger;
  cache?: Cache;
}
declare class PostgresJsSession<TSQL extends Sql, TRelations extends AnyRelations> extends PgAsyncSession<PostgresJsQueryResultHKT, TRelations> {
  client: TSQL;
  private relations;
  static readonly [entityKind]: string;
  logger: Logger;
  private cache;
  constructor(client: TSQL, dialect: PgDialect, relations: TRelations, /** @internal */

  options?: PostgresJsSessionOptions);
  prepareQuery<T extends PreparedQueryConfig = PreparedQueryConfig>(query: Query, mode: 'arrays' | 'objects' | 'raw', name: string | boolean, mapper: ((rows: any[]) => any) | undefined, queryMetadata?: {
    type: 'select' | 'update' | 'delete' | 'insert';
    tables: string[];
  }, cacheConfig?: WithCacheConfig): PgAsyncPreparedQuery<T>;
  transaction<T>(transaction: (tx: PostgresJsTransaction<TRelations>) => Promise<T>, config?: PgTransactionConfig): Promise<T>;
}
declare class PostgresJsTransaction<TRelations extends AnyRelations> extends PgAsyncTransaction<PostgresJsQueryResultHKT, TRelations> {
  static readonly [entityKind]: string;
  constructor(dialect: PgDialect, /** @internal */

  session: PostgresJsSession<TransactionSql, TRelations>, relations: TRelations, nestedIndex?: number);
  transaction<T>(transaction: (tx: PostgresJsTransaction<TRelations>) => Promise<T>): Promise<T>;
}
interface PostgresJsQueryResultHKT extends PgQueryResultHKT {
  type: RowList<Assume<this['row'], Row>[]>;
}
//#endregion
export { PostgresJsQueryResultHKT, PostgresJsSession, PostgresJsSessionOptions, PostgresJsTransaction };
//# sourceMappingURL=session.d.ts.map