import { formatToMillis } from "../migrator.utils.js";
import { useEffect, useReducer } from "react";

//#region src/expo-sqlite/migrator.ts
async function readMigrationFiles({ migrations }) {
	const migrationQueries = [];
	const sortedMigrations = Object.keys(migrations).sort();
	for (const key of sortedMigrations) {
		const query = migrations[key];
		if (!query) throw new Error(`Missing migration: ${key}`);
		try {
			const result = query.split("--> statement-breakpoint").map((it) => {
				return it;
			});
			const migrationDate = formatToMillis(key.slice(0, 14));
			migrationQueries.push({
				sql: result,
				bps: true,
				folderMillis: migrationDate,
				hash: "",
				name: key
			});
		} catch {
			throw new Error(`Failed to parse migration: ${key}`);
		}
	}
	return migrationQueries;
}
async function migrate(db, config) {
	const migrations = await readMigrationFiles(config);
	return db.dialect.migrate(migrations, db.session);
}
const useMigrations = (db, migrations) => {
	const initialState = {
		success: false,
		error: void 0
	};
	const fetchReducer = (state, action) => {
		switch (action.type) {
			case "migrating": return { ...initialState };
			case "migrated": return {
				...initialState,
				success: action.payload
			};
			case "error": return {
				...initialState,
				error: action.payload
			};
			default: return state;
		}
	};
	const [state, dispatch] = useReducer(fetchReducer, initialState);
	useEffect(() => {
		dispatch({ type: "migrating" });
		migrate(db, migrations).then(() => {
			dispatch({
				type: "migrated",
				payload: true
			});
		}).catch((error) => {
			dispatch({
				type: "error",
				payload: error
			});
		});
	}, []);
	return state;
};

//#endregion
export { migrate, useMigrations };
//# sourceMappingURL=migrator.js.map